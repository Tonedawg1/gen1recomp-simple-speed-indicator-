-- Speed Flash
-- Shows a brief on-screen readout of the active game-speed multiplier
-- whenever it changes (hotkey 1 / Options / controller R2·L2).

return function(mod)
  local GameSpeed = require("src.core.GameSpeed")

  -- Tunables
  local FLASH_DURATION = 1.25   -- seconds the label stays visible
  local FADE_START     = 0.85   -- when alpha starts falling (0–1 of duration)
  local MARGIN         = 8      -- pixels from the window edge

  local state = {
    label   = nil,   -- string to draw, e.g. "2X" or "NORMAL"
    until_t = 0,     -- love.timer time when the flash should end
    last    = nil,   -- last observed multiplier
  }

  local function now()
    return (love and love.timer and love.timer.getTime and love.timer.getTime()) or 0
  end

  -- Observe the live logic multiplier every frame. When it changes, start a flash.
  mod.hooks:wrap("core.logic_speed", function(next, game)
    local mult = next(game)
    if state.last ~= nil and mult ~= state.last then
      state.label   = GameSpeed.levelLabel(mult)
      state.until_t = now() + FLASH_DURATION
    end
    state.last = mult
    return mult
  end)

  -- Draw the flash in window space (after the finished frame, before touch controls).
  mod.hooks:wrap("render.hud", function(next, game, viewport)
    next(game, viewport)

    if not state.label then return end
    local t = now()
    if t >= state.until_t then
      state.label = nil
      return
    end

    local remaining = state.until_t - t
    local progress  = 1 - (remaining / FLASH_DURATION)   -- 0 → 1
    local alpha = 1
    if progress > FADE_START then
      alpha = 1 - (progress - FADE_START) / (1 - FADE_START)
    end
    if alpha <= 0 then return end

    local lg = love and love.graphics
    if not (lg and lg.print) then return end

    -- Prefer a readable default font; fall back gracefully.
    local font = lg.getFont and lg.getFont()
    local scale = 1
    if viewport and viewport.scale and viewport.scale >= 2 then
      scale = math.floor(viewport.scale * 0.75 + 0.5)
      scale = math.max(1, scale)
    end

    local text = state.label
    local x = MARGIN
    local y = (lg.getHeight and lg.getHeight() or 144) - MARGIN - (font and font:getHeight() or 16) * scale

    -- Soft shadow for readability on any background
    lg.setColor(0, 0, 0, 0.75 * alpha)
    lg.print(text, x + 1 * scale, y + 1 * scale, 0, scale, scale)
    lg.setColor(1, 1, 1, alpha)
    lg.print(text, x, y, 0, scale, scale)
    lg.setColor(1, 1, 1, 1)
  end)
end